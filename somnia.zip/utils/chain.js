module.exports = {
  RPC_URL: "https://dream-rpc.somnia.network/",
  CHAIN_ID: 50312,
  SYMBOL: "STT",
  TX_EXPLORER: "https://shannon-explorer.somnia.network/tx/",
  ADDRESS_EXPLORER: "https://shannon-explorer.somnia.network/address/",
};

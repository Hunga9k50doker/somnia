# ᝰ.ᐟ Somnia

Tool được phát triển bởi nhóm tele Airdrop Hunter Siêu Tốc (https://t.me/airdrophuntersieutoc)

## 🚨 Attention Before Running Somnia Cli Version

I am not `responsible` for the possibility of an account being `banned`!

## 📎 Somnia Node cli version Script features

- Auto check in
- Auto task
- Auto swap
- Auto mint
- Auto faucet
- Auto send
- Support proxy or not
- Mutiple threads, multiple accounts

## ✎ᝰ. RUNNING

- Clone Repository

```bash
git clone https://github.com/Hunga9k50doker/somnia.git
cd somnia
```

- Install Dependency

```bash
npm install
```

- Setup config in .env

```bash
nano .env
```

- Setup input value

* proxy: http://user:pass@ip:port

```bash
nano proxies.txt
```

- privateKeys: how to get privateKeys => join my channel: https://t.me/airdrophuntersieutoc

```bash
nano privateKeys.txt
```

- Setup input

```bash
node setup.js
```

- Run the script

```bash
node main.js
```
